# Handoff: Mil Palavras — "Reading Room" redesign

## Overview

A full visual + light-UX redesign of **Mil Palavras**, an offline European-Portuguese
vocabulary trainer (1000 most common words + conjugations + grammar drills, with an
SM-2-style spaced-repetition schedule). The existing app is a single self-contained
`index.html` (vanilla JS, `render*()` functions writing `innerHTML` into `#app`,
state in `localStorage`).

The redesign keeps every existing feature and flow. What changes is the surface:
the app is styled like a **well-set language book** rather than an app — ivory paper,
Newsreader serif for the language itself, hairline rules instead of cards-on-cards,
terracotta as the single accent, footnote-style usage notes, and a numbered contents
list instead of a ten-row icon menu.

Two new global rules that must be honoured everywhere:

1. **Portuguese-first, English underneath.** Every Portuguese string in the interface
   carries an English translation — stacked underneath for headings/body copy, or
   inline as `PT · EN` for short chrome labels (e.g. `RÉVER · REVIEW`, `SEGUINTE · NEXT`).
   This includes KPI numbers ("por rever" / "due for review"), section titles,
   grammar notes, settings fields, and every explanatory sentence.
2. **English-respelled pronunciation, not IPA.** Show `koo-ZEE-nyah`, not `ku·ˈzi·ɲɐ`.
   Stressed syllable in CAPS, syllables joined with hyphens.

## About the design files

`Reading Room.dc.html` (with `support.js`) in this bundle is a **design reference
prototype written in HTML** — it demonstrates the intended look, copy, and behaviour.
It is **not production code to copy**. The task is to recreate these designs inside the
existing `index.html` app (vanilla JS + a `<style>` block), following that codebase's
established patterns: keep the `render*()` function structure, `h()` innerHTML rendering,
`on()` event binding, the `S` state object, `localStorage` persistence, and the
existing SM-2 scheduling logic. Only markup, CSS and copy should change.

Open the prototype in a browser. A switch at the top toggles between the **iPhone**
and **Web** presentation of the same 13 screens; both are clickable.

## Fidelity

**High fidelity.** Colours, type sizes, weights, spacing and copy are final and should
be matched closely. Layout structure (rules, column widths, stacking order) is
prescriptive. Where the prototype shows 3–6 sample words, the real app uses the full
`window.__DATA__` dataset.

---

## Design tokens

### Colour (all values are the literal strings used)

| Token | Value | Use |
|---|---|---|
| `--paper` | `oklch(96.5% .018 85)` ≈ `#F6F0E4` | Page background |
| `--card` | `#FFFDF9` | Raised note cards (footnotes, example sentences) |
| `--ink` | `oklch(23% .025 45)` ≈ `#3A2A20` | Primary text, rules, primary buttons |
| `--slate` | `oklch(50% .02 50)` ≈ `#7E7169` | Secondary Portuguese text |
| `--slate-en` | `oklch(58% .02 50)` ≈ `#948780` | **English translation lines** |
| `--slate-en-2` | `oklch(60% .02 50)` / `oklch(62% .02 50)` | English body copy, sub-sub lines |
| `--terracotta` | `oklch(55% .16 40)` ≈ `#B4552F` | Accent: eyebrows, numerals, active nav, "again" |
| `--teal` | `oklch(45% .07 195)` ≈ `#3F6E70` | Second accent: correct, "Bom", footnote rule |
| `--ochre` | `oklch(60% .12 70)` | "Difícil" grade |
| `--vinho` | `oklch(48% .16 20)` | "Outra" grade, wrong answers |
| Rules | `oklch(23% .025 45 / .14)` hairline · `/ .18` · `/ .25` · solid `2px` ink for section tops | |

Dark bezel for the device frame: `#20180f`.

### Typography

| Role | Font | Size / weight / spacing |
|---|---|---|
| Portuguese language content, headings, numerals | **Newsreader** (Google), 300–600, italic used for the wordmark and intros | Word of the day 46px/1.0 (mobile) · 64–66px (web) · screen titles 34px (mobile) / 40–42px (web) · list items 19–21px · table cells 17.5–20px · stat numerals 24–44px |
| Interface labels, English lines, buttons | **Karla** (Google), 400–700 | Eyebrows 9px `.20–.22em` uppercase 700 · English lines 10–13.5px · list subtitles 11.5–12px |
| Counters, progress, data, keyboard hints | **IBM Plex Mono**, 400–500 | 10–12px |

Google Fonts: `Newsreader:ital,opsz,wght@0,6..72,300..600;1,6..72,300..500`,
`Karla:wght@400;500;600;700`, `IBM+Plex+Mono:wght@400;500`.

### Shape, spacing, elevation

- **Radius: 0 everywhere.** No rounded cards, no pills. The only radii in the design
  are the device bezel and the 6px mastery dots.
- Elevation is expressed as **rules and inset shadows**, never drop shadows:
  - note card: `background:#FFFDF9; box-shadow: inset 0 0 0 1px oklch(23% .025 45 / .12)`
  - footnote card: `box-shadow: inset 3px 0 0 oklch(45% .07 195)` + `padding-left:+2px`
  - outline button: `box-shadow: inset 0 0 0 1.4px <ink>`
- Mobile screen padding `26px`; web page padding `34px 46px 46px`.
- Section tops use `border-top:2px solid <ink>`; list rows `border-bottom:1px solid <ink>/.14`.
- Accent-key and stepper buttons are 46×46px (touch target minimum).

---

## Screens

All 13 exist on both phone and web. Screen keys match the prototype's state machine
and map to the existing app's `go()` router.

| Key | Title (PT · EN) | Replaces in current code |
|---|---|---|
| `home` | Início · Home | `renderHome()` |
| `review` | Rever · Review | `renderSession()` / `renderFlip()` |
| `summary` | Sessão completa · Session complete | `renderSummary()` |
| `flash` | Cartões · Flashcards | `renderDeckPicker("flash")` |
| `choice` | Escolha múltipla · Multiple choice | `renderChoice()` |
| `type` | Escrever · Type it | `renderType()` |
| `gender` | O ou A? · Noun gender | `renderGender()` |
| `conj` | Conjugações · Conjugations | `renderDrillPicker("conjugacao")` |
| `grammar` | Gramática · Grammar | `renderGrammar()` |
| `topic` | (topic title) | grammar topic detail |
| `browse` | Dicionário · Dictionary | `renderBrowse()` |
| `settings` | Definições · Settings | `renderSettings()` |
| `method` | Método · Method | `renderMethod()` |

### 1. Home (`home`)

**Purpose:** orient, show today's load, offer one word to chew on, route everywhere else.

**Layout, phone (top → bottom):**
1. Centred masthead: `Mil Palavras` in Newsreader *italic* 34px; under it
   `CADERNO · NOTEBOOK · DIA 42` — 9px, `.28em`, uppercase, terracotta, 700.
   Bottom rule `1px ink/.25`.
2. **Word of the day** — a tappable block (not a card), 26px vertical padding, centred:
   - eyebrow `A PALAVRA DE HOJE · WORD OF THE DAY` (9px, `.22em`, teal)
   - front: word in Newsreader 46px ink; pronunciation in Plex Mono 11.5px slate
     (`koo-ZEE-nyah`)
   - back (after tap): English 30px terracotta + example sentence in Newsreader italic 17px
   - hint `TOQUE PARA VIRAR · TAP TO TURN` 9px `.18em`
   - bottom rule.
3. **Three KPI columns** split by 1px vertical rules: numeral Newsreader 28px
   (terracotta / teal / ink), PT label 8.5px `.16em` uppercase, **English label 10px**
   directly under it — `por rever / due for review`, `dias seguidos / day streak`,
   `começadas / words started`.
4. **Numbered contents list**, one row per destination: `01`–`10` in Plex Mono 10px
   terracotta, PT title Newsreader 20px, English subtitle 11.5px slate, count in
   Plex Mono 11px right-aligned, row `padding:15px 0` + hairline bottom rule.
   Order: Rever hoje · Cartões · Escolha múltipla · Escrever · O ou A? · Conjugações ·
   Dicionário · Gramática · Método · Definições.
5. Footer: Portuguese line in Newsreader italic 14.5px, English 12px underneath —
   "Funciona sem ligação à internet…" / "Works with no signal. Nothing leaves this device…"

**Web:** the masthead is left-aligned with the three KPIs (PT + English labels) on the
right, over a 2px rule. Below it a sticky **172px contents rail** (PT label, English
underneath, active item terracotta) carries all navigation — the home page must **not**
repeat that list anywhere. The body to its right is a dashboard in two wrapping rows:

*Row 1* — left (`flex:1 1 420px; min-width:420px`): the word of the day between two 2px
rules, display size `clamp(42px,5.4vw,64px)`, with two buttons under it
(`Rever · review · 12` filled ink, `Gramática · grammar` outlined).
Right (`flex:1 1 300px; min-width:280px; max-width:340px`): **A fila de hoje · today's
queue** — a 52px terracotta numeral with "cartões por rever / cards due · about 6 minutes",
then a three-row breakdown (palavras/words 8 · verbos/verbs 3 · gramática/grammar 1) —
followed by **Progresso · progress**, three 3px mastery bars (Substantivos 312/420
terracotta, Verbos 88/190 terracotta, Gramática 40/130 teal).

*Row 2*, under a 2px rule — left: **Esta semana · this week**, seven bars (today in
terracotta, the rest `ink/.18`) with PT day abbreviations and the line "184 cartões
classificados, 91% de acerto" + English. Right: **Continuar · pick up where you left off**
— a teal-ruled card resuming the last grammar topic (title, "lido a meio · half read",
a PT sentence naming what is left, English under it), then **Erros frequentes · frequent
misses**, three rows with `×6` counts in Plex Mono terracotta.

**Responsive rule for every two-column web screen** (home, review, choice, topic): the row
is `display:flex; flex-wrap:wrap` with a `flex:1 1 420px; min-width:420px` main column and
a `flex:1 1 300px; min-width:280px; max-width:340px` side column, so the side column drops
below the main column instead of squeezing it. Never pair a fixed-width side column with an
unconstrained `flex:1` main column — display type at 44–66px will overflow it.

### 2. Review (`review`)

Progress: label row (`REVER · REVIEW` terracotta / `07 / 24` Plex Mono) over a 2px
track (`ink/.14`) filled terracotta.

Card face is again typography on paper, not a box: klass eyebrow (`SUBSTANTIVO ·
FEMININO`) → word Newsreader 46px (66px web) → pronunciation Plex Mono → on reveal a
44px hairline and the English in Newsreader 28px terracotta.

On reveal, two note blocks appear (phone: stacked under the card; web: in a 320px right
column):
- **Numa frase · in a sentence** — `#FFFDF9` inset-1px card, PT sentence Newsreader 19px,
  English 12.5px slate.
- **Footnote** — `#FFFDF9` with `inset 3px 0 0 teal`, PT note Newsreader 15.5px,
  English 12.5px underneath.
- Web additionally shows an always-visible **Erros frequentes · frequent misses** card in the side column.

Grades: 4 equal columns, `gap:7px` (10px web), each a square-cornered outline button —
label 13.5px 700 in its colour (Outra=vinho, Difícil=ochre, **Bom**=teal with `inset 0 0
0 2px`, Fácil=terracotta) over the interval in Plex Mono 9.5px (`10m · 1d · 3d · 8d`).
Web adds the keyboard hint line `espaço = virar · 1–4 = classificar · s = ouvir`.

### 3. Session summary (`summary`)

Newsreader italic 40px `Sessão completa` + English 13px + terracotta meta line
(`24 cartões · 6 minutos · cards, minutes`). Two (phone) or three (web) stat columns with
PT + English labels. `Voltam amanhã · back tomorrow` list of leeches with `×6` counts in
Plex Mono terracotta. Filled `Mais dez palavras · ten more` + outlined `Voltar ao início ·
back home`.

### 4. Cartões / Conjugações / Gramática pickers (`flash`, `conj`, `grammar`)

Identical pattern: title Newsreader 34px, English 12px under it, PT intro in Newsreader
italic 15px, English intro 12.5px, then a `2px` top rule and a list of rows
(PT title 19px, English title 11.5px, PT sub 11.5px, count Plex Mono right).

### 5. Grammar topic (`topic`)

Back link `‹ GRAMÁTICA · GRAMMAR`. Title + English + PT/EN intro. Then a text table
built from rules, not borders: header row 8.5px `.18em` uppercase slate over a `2px`
ink top rule; each row = 30–32% label column (12.5px slate) + N equal cells in
Newsreader 17.5px. Footnote card (teal inset rule) with PT note + English under it —
on web it sits in a 300px right column. Closing outline button
`Testar isto · test this · N cartões`, which drops the topic's cards into the same
SM-2 queue.

Six topics ship with real content: Contrações, Plurais, Ser e estar, Pronomes,
Possessivos, Adjetivos (see `TOPICS` in the prototype's logic for the exact tables,
intros, notes and their English translations).

### 6. Multiple choice (`choice`)

Prompt eyebrow `VERBO · PRESENTE · VERB, PRESENT`, prompt Newsreader 40px (52px web),
four full-width square options (`#FFFDF9`, `inset 1px ink/.18`, Newsreader 16px).
After answering: correct option gets `inset 0 0 0 2px teal` + teal text; the chosen wrong
one `inset 2px vinho`; others `opacity:.4`. The full conjugation table is then revealed
(phone: below; web: 320px right card) with the tested cell in terracotta, plus a PT+EN
rule note. `Seguinte · next` filled button.

### 7. Type it (`type`)

Prompt `ESCREVE EM PORTUGUÊS · WRITE IT IN PORTUGUESE`, English word Newsreader 32px.
The input is a writing line, not a box: text Newsreader 30px over
`border-bottom:2px solid terracotta`, min-height 56px. Accent row: `á ã â ç é ê í ó õ ú`
plus `⌫`, each 46×46 with `inset 1px ink/.25`. On check, a teal-ruled card shows
`CERTO · CORRECT`, the answer `a cozinha`, `the kitchen · koo-ZEE-nyah`, and the PT note
with its English line. Button toggles `Verificar · check` → `Seguinte · next`.

### 8. o ou a? (`gender`)

`QUAL É O ARTIGO? · WHICH ARTICLE?`, noun without its article in Newsreader 46px (60px web)
+ English 13px. Two 1fr buttons `o` / `a`, Newsreader 40px, 30px vertical padding;
after answering the correct one takes `inset 2.5px teal`, a wrong pick `inset 2.5px vinho`,
the other dims to `.4`. Explanation card (teal rule) states the ending rule in PT with
English underneath. `Seguinte · next`.

### 9. Dicionário (`browse`)

Title + English; search row is a 2px-ruled line with a 15px stroke magnifier and
`Procurar entre 1000 palavras · search 1000 words`. Class filter is a row of uppercase
10px `.16em` text links (`todas · all`, `substantivos · nouns`, …); the active one is
terracotta with a `2px` bottom border. Entries group under thematic headings
(`Em casa · at home`) and are: 6px mastery dot (teal known / ochre learning /
`ink/.2` new), PT word Newsreader 18px, English right-aligned 12.5px, hairline rule.
Web renders the same list in **two columns with a 1px column rule** (`column-count:2;
column-gap:48px`).

### 10. Definições (`settings`)

Stacked fields separated by hairlines: `Palavras novas por dia` + `New words per day` +
PT hint + English hint, with a −/+ stepper (46×46 outline buttons, value Newsreader 30px).
`Direção · direction` as three square segments (active = filled ink). Three toggle rows
whose state is a text chip, not a switch: `ligado · on` filled teal / `desligado · off`
outlined. Data block: `Os teus dados · your data` with a Plex Mono summary and two
outline buttons `Exportar · export`, `Importar · import`.

### 11. Método (`method`)

Numbered `01`–`06` rows: PT title Newsreader 19–20px, English title 11.5–12px, PT body
13px, English body 12px. Web sets the list in two columns.

---

## Interactions & behaviour

- **Flip:** tapping the word (home hero or review card) reveals the translation, the
  example and the footnote. In the current codebase this is the `.flipper`/`.face`
  rotate; in this design the flip is a **fade/replace** — no 3D rotation, no card shape.
  Keep it fast (≤180ms) or instant under `prefers-reduced-motion`.
- **Grading** advances to the next card and applies the existing SM-2 update untouched.
  The four intervals shown (`10m / 1d / 3d / 8d`) must be the real computed next-due
  values, not fixed strings.
- **Answer feedback** is expressed only through the inset-ring colour and text colour —
  no background fills, no icons.
- **Audio** (`say`/`autoSay`) is unchanged; on this design the trigger is a text button
  (`OUVIR ▶`-style small caps) rather than a floating circular FAB.
- **Navigation:** phone uses back links (`‹ INÍCIO · HOME`); web uses the persistent
  sticky contents rail with the active item in terracotta. No bottom tab bar.
- **Keyboard (web):** space flips, 1–4 grade, S speaks — surface the hint line under the
  grade row.
- Hover (web only): list rows lift to `ink` text with the hairline turning `ink/.3`;
  buttons invert (filled ink ⇄ paper). Touch devices get no hover state.

## State

No new state. The prototype's state maps onto what already exists:
`screen` (`go()` router), `revealed` (`SES.shown`), `i`/`total` (`SES.i`, `SES.q`),
`choice`/`gender`/`typed` (per-question answer state), `topic` (grammar detail),
plus persisted settings `perDay` (`S.set.new`), `dir` (`S.set.dir`) and the three
toggles. All persistence stays in `localStorage`; nothing leaves the device.

## Content requirements

- Every user-facing Portuguese string needs an English counterpart. The prototype's
  `TOPICS`, `METHOD`, `CARDS`, `BROWSE`, `navItems`, `homeItems`, `decks`, `tenses` and
  `toggles` arrays contain finished bilingual copy — lift it verbatim.
- `note` / `noteE` and `ex` / `exE` fields must be added to the card data. The current
  `window.__DATA__` has `s` (a source/tag string) but no example sentence, note, or
  pronunciation: **three new per-card fields are needed** — `ipa` (English respelling),
  `ex`/`exE`, `note`/`noteE`. Ship them progressively; cards without them simply render
  the card face and grades.
- Pronunciation respelling rules: hyphenate syllables, CAPS the stressed one, use
  English-intuitive graphemes (`nh` → `ny`, final unstressed `-e` → `uh`, `s` before a
  consonant/at the end → `sh`). Examples: `a cozinha` → koo-ZEE-nyah; `o telhado` →
  tuh-LYAH-doo; `ficar` → fee-KAR; `a época` → EH-poo-kuh; `devagar` → duh-vuh-GAR;
  `nós fazemos` → noosh fuh-ZEH-moosh.

## Assets

None. No images, no icon font. The only vector art is three inline stroke SVGs
(magnifier, speaker, chevron) at `stroke-width:1.6–1.9`, `currentColor`. Fonts load
from Google Fonts — if the app must stay fully offline, self-host Newsreader, Karla and
IBM Plex Mono as woff2 and keep the same stacks.

## Files in this bundle

- `Reading Room.dc.html` — the interactive prototype (iPhone + Web, all 13 screens).
  Its `<script data-dc-script>` block holds the bilingual content data and all
  interaction logic; the markup above it holds the exact styles quoted in this README.
- `support.js` — runtime required to open the prototype locally. Not part of the design.

Reference for the current implementation: the app's own `index.html`
(`renderHome`, `renderSession`, `renderBrowse`, `renderGrammar`, `renderSettings`, …).
