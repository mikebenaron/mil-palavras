# Handoff: Mil Palavras — navigation, home, session and theme redesign

## Overview

Mil Palavras is a European-Portuguese vocabulary app (existing repo: `mikebenaron/mil-palavras`, a single-file vanilla-JS `index.html` PWA). This handoff covers a redesign that fixes four problems the owner reported: the home screen was a long scroll of ~17 tiles, navigation was a flat list of destinations with back-links, dark mode had no visible surface separation, and audio/progress were buried.

The redesign keeps the app's existing identity — warm paper, hairline rules, Newsreader/Karla/IBM Plex Mono, terracotta + teal accents — and changes **structure**, not the visual language.

Four things change:

1. **Two navigation levels only.** *Places* keep a tab bar (Hoje, Ler, Estudar, Memória, Eu). *Sessions* take the whole screen: no tab bar, a counter and `sair` at the top, one action pinned at the bottom.
2. **Estudar is a page, not a grid of everything.** It groups modes (Rever / Praticar / Ler & falar / Referência), then asks which set of words (Por rever, Tudo, Nomes, Verbos, Outras palavras, Difíceis, Aleatório) — mode → bucket → session.
3. **Home answers one question**: what do I do now. Session panel, "a seguir", 7-day forecast chart, one plain-language progress line.
4. **Three themes** — claro / escuro / noite — with escuro rebuilt so surfaces actually separate.

Plus seven learning-UX improvements requested by the owner: audio-first cards, session length up front, context before translation, progress in plain words, word families, night mode, honest empty state. Each is described under **Interactions & Behavior**.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes showing intended look and behaviour, **not production code to copy directly**.

The existing app is a single-file vanilla-JS PWA (`index.html`, ~6 500 lines, hash-router, CSS custom properties, no build step, no framework). **The task is to recreate these designs inside that existing environment and its established patterns** — the same `:root` custom-property system, the same `renderX()` render functions, the same `localStorage` persistence — not to introduce React or port the prototype's code. The prototype is written as a component with a small state object purely because that was the fastest way to make the flows clickable; treat its structure as a specification of behaviour, not as an architecture proposal.

Two files:

- **`Mil Palavras - Protótipo.dc.html`** — the working prototype. Navigable: tabs, Estudar mode→bucket flow, a real review session over 12 EU-PT cards with grading that reschedules, multiple choice, reading with tap-a-word glosses and a read-along player, a branching conversation, dictionary with class filters, and settings with live theme switching. This is the primary reference.
- **`Mil Palavras - Redesign.dc.html`** — the exploration board that preceded it. Turn 1 holds four structural options (1a one-view home, 1b session+drawer, 1c web dashboard, 1d dark-mode fix); turn 2 holds 13 static screens in the chosen 1b direction, including several screens the prototype does not implement (Escrever, Ditado, Falar with pronunciation scoring, the web dashboard). Use it for the screens the prototype omits, and for the desktop layout.

Both open directly in a browser. The prototype needs `support.js` (included) beside it.

## Fidelity

**High-fidelity.** Colours, typography, spacing and copy are final and should be recreated faithfully. Every value below is exact. Two deliberate exceptions:

- The prototype's deck is 12 hand-written cards, not the app's ~1 105. Counts, percentages and the forecast chart are computed from those 12 — the *formulas* are the spec, not the numbers.
- Audio is simulated (a `speaking` flag with a timeout). Wire the real `Audio` playback and rate control in its place.

## Design tokens

Existing tokens from the repo's `:root` are kept. The **dark theme is retuned** and a **night theme is new**. All colours are oklch (as in the current codebase).

### Light (`:root`)

| Token | Value | Use |
|---|---|---|
| `--paper` | `oklch(96.5% .018 85)` | page background |
| `--card` | `#FFFDF9` | raised objects: notes, chips, family cards |
| `--panel` | `oklch(23% .025 45)` | inverted session panel |
| `--onpanel` | `oklch(96.5% .018 85)` | text on panel |
| `--onpaneldim` | `oklch(96.5% .018 85 / .68)` | secondary text on panel |
| `--onpanelac` | `oklch(78% .09 190)` | accent on panel (teal, lifted) |
| `--onpanelrule` | `oklch(96.5% .018 85 / .26)` | rules on panel |
| `--ink` | `oklch(23% .025 45)` | primary text |
| `--slate` | `oklch(50% .02 50)` | secondary text |
| `--slate2` | `oklch(58% .02 50)` | tertiary text, English glosses |
| `--terra` | `oklch(55% .16 40)` | primary accent (terracotta) |
| `--teal` | `oklch(45% .07 195)` | secondary accent, "correct", section labels |
| `--ochre` | `oklch(60% .12 70)` | "close but not right", reading highlight |
| `--vinho` | `oklch(48% .16 20)` | wrong, destructive |
| `--rule` / `--rule2` / `--rule3` | `oklch(23% .025 45 / .14 / .18 / .25)` | hairlines: list dividers / object outlines / section dividers |
| `--btn` / `--onbtn` | `oklch(23% .025 45)` / `oklch(96.5% .018 85)` | primary button |

### Dark (`[data-theme="dark"]`) — the fix

The current app sets paper at 19% L and card at 23% L: four points apart, which is why nothing reads as separated. The fix is three changes, no new hues:

| Token | Was (current app) | Now | Why |
|---|---|---|---|
| `--paper` | `oklch(19% …)` | `oklch(16% .01 75)` | widen paper↔card to 6 points |
| `--card` | `oklch(23% …)` | `oklch(22% .012 75)` | |
| `--panel` | — | `oklch(26% .014 75)` | panel must sit *above* card in dark |
| `--rule` / `--rule2` / `--rule3` | `.16 / .22 / .30` alpha | `oklch(94% .01 85 / .2 / .26 / .32)` | hairlines vanish at 16% on a dark ground |
| `--terra` | `oklch(70% .13 42)` | `oklch(76% .13 42)` | +6 L, same hue and chroma |
| `--teal` | `oklch(72% .09 190)` | `oklch(80% .085 190)` | +8 L |
| `--ink` / `--slate` / `--slate2` | — | `oklch(94% .01 85)` / `oklch(74% .014 60)` / `oklch(68% .014 60)` | |
| `--btn` / `--onbtn` | — | `oklch(94% .01 85)` / `oklch(16% .01 75)` | inverts in dark |
| `--ochre` / `--vinho` | — | `oklch(80% .11 75)` / `oklch(70% .15 22)` | |
| `--onpanel` / `--onpaneldim` / `--onpanelac` / `--onpanelrule` | — | `oklch(94% .01 85)` / `… / .7` / `oklch(80% .085 190)` / `… / .3` | |

### Night (`[data-theme="night"]`) — new

Warmer and lower in contrast, for reading in bed. Not a dimmed dark theme — the hue shifts to 60–78.

`--paper: oklch(24% .022 60)` · `--card: oklch(28% .024 60)` · `--panel: oklch(32% .026 60)` · `--ink: oklch(86% .022 75)` · `--slate: oklch(70% .02 65)` · `--slate2: oklch(64% .02 65)` · `--terra: oklch(72% .11 45)` · `--teal: oklch(74% .07 190)` · `--ochre: oklch(76% .1 78)` · `--vinho: oklch(66% .13 25)` · `--rule/2/3: oklch(88% .02 70 / .16 / .22 / .28)` · `--btn/--onbtn: oklch(86% .022 75)` / `oklch(24% .022 60)` · `--onpanel: oklch(88% .02 70)` · `--onpaneldim: oklch(88% .02 70 / .7)` · `--onpanelac: oklch(76% .07 190)` · `--onpanelrule: oklch(88% .02 70 / .24)`

**Theme resolution.** Stored preference is one of `light | dark | night | auto`; `auto` resolves to `dark` when `matchMedia('(prefers-color-scheme: dark)')` matches, else `light` — and must re-resolve live on the media-query `change` event. The resolved value goes on `document.documentElement[data-theme]` (not on an inner wrapper) so `html`/`body` background follows it and iOS overscroll and safe-area edges don't flash cream. Persist the preference; `night` is never auto-selected.

### Typography

Three families, already in the repo's `fonts/`:

- **Newsreader** (serif) — every Portuguese-facing string, numerals, headings, buttons. Italic for quiet asides and example sentences. Weights 300–600.
- **Karla** (sans) — English glosses, body copy, sub-lines. 400/600/700.
- **IBM Plex Mono** — metadata, counts, intervals, uppercase micro-labels. 400/500.

| Role | Font | Size | Other |
|---|---|---|---|
| Screen title | Newsreader | 32px | line-height 1.05 |
| Session number (home) | Newsreader | 88px | line-height .8 |
| Card front word | Newsreader | 48px | line-height 1.04 |
| Card back word | Newsreader | 32px | |
| Translation ("significa") | Newsreader | 26px | `--terra` |
| Example sentence | Newsreader italic | 20px | line-height 1.45 |
| Reading body | Newsreader | 20.5px | line-height 1.75 |
| List row title | Newsreader | 18–19px | |
| Button label | Newsreader | 20–21px | |
| English gloss under a PT string | Karla | 10–12.5px | `--slate2` |
| Section label | Karla | 10.5–11px | `letter-spacing .18–.22em`, uppercase, weight 700, `--teal` or `--slate` |
| Metadata / counts | IBM Plex Mono | 9.5–11px | often `letter-spacing .1–.14em`, uppercase |
| Stat numeral | Newsreader | 28–38px | line-height 1 |

### Spacing, shape, hit targets

- Horizontal page gutter **22px**; section gap 20–24px; list row padding 11–15px vertical.
- **Nothing is rounded.** No `border-radius` anywhere — the identity is rules and rectangles.
- **No box shadows for elevation.** `box-shadow: inset 0 0 0 1px <rule>` is the outline idiom; `inset 3px 0 0 <accent>` marks a note; `inset 0 2px 0 <accent>` marks the selected tab; `inset 0 0 0 2px --terra` rings the Estudar tab button.
- Tab bar 62px tall + `env(safe-area-inset-bottom)`; primary buttons 56–58px; every control ≥44px in both axes (audio speed chips are 46×44).
- Bilingual pattern: Portuguese in Newsreader on the first line, English in Karla `--slate2` immediately under it, or as a mono uppercase label at the opposite end of a flex row.

## Screens / views

Tab bar order: **Hoje · Ler · [Estudar] · Memória · Eu**. Estudar is the visually distinct centre item — a filled `--btn` block with `--onbtn` text, not a text tab. Selected text tabs get `inset 0 2px 0 --terra` and `--terra` text; unselected are `--slate`.

### 1. Hoje (home) — `isHoje`

The whole point: no scroll to the decision, one CTA. Vertical flow:

1. **Header** — "Mil Palavras" (Newsreader italic 19px) left; right, "dia 47" mono 10.5px `--terra` + a **theme cycle button** (44px tall, 1px `--rule2` outline, an 11px swatch of `--paper` with a `--rule3` outline, and a mono 9.5px label reading `claro · light` / `escuro · dark` / `noite · night` / `auto`). Tapping cycles light→dark→night→auto.
2. **Session panel** — full-bleed `--panel`, 26px 22px 24px. Two variants (see empty state below). With cards due: teal label `a sessão de hoje · today's session`; the planned count at Newsreader 88px; beside it the italic line `10 dos 23 por rever · cerca de 5 min` with its English under it; a rule; a three-up split `palavras N / verbos N / outras N` each with an English sub-label; the **session-length picker**; then the CTA — a full-width 58px `--onpanel` block with `Começar` (Newsreader 21px, `--panel`) and `start · 10 cards` beside it.
3. **A seguir · then** — three rows, 1px `--rule` dividers, each PT title + inline English gloss + a `--slate2` detail line + a `--terra` `→`: *Continuar a leitura*, *Conversa*, *Dicionário*.
4. **Próximos 7 dias** — the forecast chart (below).
5. **Progress footer** — a mono row `96 sabes · 214 começadas` / `de 990`; a 6px two-segment bar (`--teal` known, `--terra` started-not-known, on `--rule`); then the **plain-words line** at Newsreader 19px with its English under it.

### 2. Ler (read) — `isLer`

Title + count line. The in-progress text is a `--panel` card: mono `a continuar · carry on · a2`, title Newsreader 24px `--onpanel`, English sub-line, a 4px progress bar in `--onpanelac`, and `linha 9 de 24 · conto tradicional`. Below it, one row per text: a mono CEFR badge (`--teal` for A1/A2, `--terra` for B1/B2), title, `source · length` line. Texts not in the prototype are at `opacity .55` with a right-aligned two-line `não no protótipo / not in prototype` marker — in production these are simply live rows.

### 3. Estudar (study) — `isEstudar` → `isBucket`

**Step 1 — how.** Title + `escolhe como — depois o conjunto · pick how, then which set`. Four groups, each headed by a two-part label (PT uppercase `--teal` left, English mono `--slate2` right):

- **rever / due now** — two full-width rows with counts: *Rever hoje* (`--terra` count), *Difíceis*. These skip step 2 and start immediately, because the scheduler already owns that queue.
- **praticar / practise** — 2-column grid of `--card` tiles with 1px `--rule2` outline: Cartões (flashcards), Escolha (multiple choice), Escrever (type it), Ditado (dictation), Falar (speaking), O ou A? (noun gender).
- **ler & falar / read & speak** — Leitura, Conversa.
- **referência / reference** — Dicionário, Gramática.

Footer line: settings live under Eu. (Reference and settings deliberately do **not** live here as a flat 17-item list — that was the original problem.)

**Step 2 — which set.** `← estudar · study` back control; the chosen mode as a teal label; `Que conjunto? · which set`; a `--panel` strip holding the session-length picker; then one row per bucket with its count and a `→`: **Por rever** (due today), **Tudo** (whole deck), **Nomes** (nouns), **Verbos** (verbs), **Outras palavras** (adverbs & phrases), **Difíceis** (trouble words), **Aleatório** (random, shuffled). Empty buckets are omitted, never shown dead.

### 4. Memória (memory) — `isMem`

Title + `o que o teu caderno sabe sobre ti`. Then: the **plain-words coverage card** (`--card` with `inset 3px 0 0 --teal`); a three-up stat block over a 2px `--ink` top rule — *sabes* (`--teal`, "21+ dias"), *começadas*, *difíceis* (`--terra`, "2+ lapsos"); a **hoje** row of three `--card` tiles (revistas / acertadas / por rever); and **o teu caderno · your deck** — up to 8 rows of word + English + a right-aligned state (`sabes` teal / `N lapsos` terracotta / `12 d` slate / `nova` slate2) with an English sub-label.

### 5. Eu (you · settings) — `isEu`

All settings live here, nowhere else.

- **aspecto · appearance** — a four-up segmented control (Claro / Escuro / Noite / Auto), each cell 12px tall with a Newsreader PT label and a 9.5px English sub-label; selected cell is `--btn`/`--onbtn`, the group is outlined `inset 0 0 0 1px --rule3`. Two explanatory lines under it, PT then English, that change with the selection (auto states which theme is currently resolved; night explains it is warmer and lower-contrast).
- **estudo · study** — *Palavras novas por dia* with a −/+ stepper (44px targets, 2–20 in steps of 2) and the note that it caps intake, never reviews; *Velocidade do áudio* as three chips (lento 0,7× / normal 0,85× / natural 1×).
- **sem ligação · offline** — audio-library card, filled bar, `5 412 clips · 185 MB · duarte pt-pt, 48 kHz`.
- **Recomeçar o protótipo** (`--vinho` outline) — in production this is *Apagar o meu progresso*, and must confirm.
- A closing privacy paragraph, PT then English: the notebook stays on the device; three features talk to a server — Falar, the daily text, Conversa.

### 6. Session: Rever (review) — `isRever`

The session frame, shared by every mode: `← sair · quit` top-left, `7 / 23` top-right, a 3px `--terra` progress bar under them, **no tab bar**.

**Front** (`notShown`) — centred: class label (`substantivo · masculino`) with its English under it; the word at Newsreader 48px; the pronunciation respelling in mono 12px; then the **context card** — `--card`, 1px `--rule2`, teal micro-label `no contexto · in context`, and the example sentence with the target word replaced by `____` (Newsreader italic 18px, left-aligned); then `toca para virar / tap to turn it over`. The whole area above the audio bar is the reveal target. Pinned above the bottom edge: the **audio bar**.

**Back** (`shown`) — order matters, and it is deliberately context-before-meaning:

1. Centred word + `respelling · noun · masculine`, then an inline audio row (play + three speed chips), over a `--rule3` divider.
2. `no contexto · in context` — the full Portuguese sentence, Newsreader italic 20px. **No English yet.**
3. `significa · it means` — the English translation at Newsreader 26px `--terra`, then the English sentence at 12.5px `--slate2`.
4. `família / words it travels with` — a wrapping row of `--card` chips, each a related PT word with its English (e.g. *o comboio* → a estação, o bilhete, a linha, atrasado).
5. `nota · note` where the card has one — `--card` with `inset 3px 0 0 --teal`, PT note then English note. These carry the EU-vs-BR distinctions (comboio not trem, casa de banho not banheiro, `estar a` + infinitive not the gerund).
6. A mono row: `estabilidade 12 d` / `lapsos 1`, each with an English sub-label.

Bottom: **four 70px grade buttons** — *Outra vez* (`--vinho` outline, "hoje", "again"), *Difícil* (`--rule3` outline), *Bom* (filled `--btn`), *Fácil* (`--teal` outline). Each shows its resulting interval, computed from the card's current state, plus a small English word.

### 7. Session: Escolha (multiple choice) — `isEscolha`

Same session frame. Prompt `o que significa / what does it mean`, the word at Newsreader 42px, `respelling · class`, an audio row, and the context card. Four options as full-width 56px buttons, `--card` with `--rule3` outline. After a pick: correct option turns `--teal` (outline + text + `certo · right`), a wrong pick turns `--vinho` (`errado · wrong`), the rest fade to `--slate2`/`--rule`. A bottom bar then appears with a two-line explanation and **Seguinte · next** — the pick is *not* graded until Seguinte, so the learner can read the answer first.

### 8. Session end — `isFim`

Full `--panel` screen. Mono `dia 47 · 13 seguidos · day streak`; `sessão terminada · session over`; "Já chega / por hoje." at Newsreader 42px with the English italic under it; two lines saying what comes back tomorrow and at what new-word pace; a three-up stat block between two `--onpanelrule` rules (revistas / outra vez / acertadas). Two actions: *Ler um texto* (filled `--onpanel`) and *Voltar ao início* (outlined).

### 9. Leitura: passage — `isReading`

`← ler · read` and `a2 · linha 3 de 5`; a 3px `--teal` progress bar. Title + English title + provenance line. The body is one block per line at Newsreader 20.5px/1.75; the **active line** is tinted `oklch(from var(--ochre) l c h / .16)`. Glossable words carry `inset 0 -2px 0 --ochre` and are tappable; tapping opens a **gloss card** above the bottom bar — lemma, English, and a grammar note in both languages (`pretérito imperfeito, 3.ª pessoa` / `past imperfect, 3rd person`) with a `fechar · close` control. Bottom bar: a 52px play button (glyph `▶`/`❚❚`) that advances the highlighted line every 2 600 ms, a `Ler comigo · read along` label with the live rate, and a `linha → / next line` step button.

### 10. Conversa — `isConversa`

`← sair · quit` / `no café · at the café`. A `--card` banner with `inset 3px 0 0 --teal` stating the constraint: it only uses words you have earned, with the live counts. Thread: their turns are `--card` with a `--rule2` outline, left-aligned, English under each; your turns are `--panel`/`--onpanel`, right-aligned; **corrections** are left-aligned `--card` with `inset 3px 0 0 --ochre` — e.g. choosing "Sim, quero um café" returns *Quase — "queria" é mais suave a pedir, e em Portugal usa-se sempre.* Bottom: `escolhe a tua resposta · pick your reply` and 2–3 reply buttons, each PT with English under it. When the scenario ends, the label becomes `conversa terminada · conversation over, nothing was stored`.

### 11. Dicionário — `isDic`

`← voltar · back` / `N cartões · cards`. Title, then four filter chips as a flex row (tudo/all, nomes/nouns, verbos/verbs, outras/other) — selected is `--btn`/`--onbtn`. Rows: word Newsreader 20px, English 12.5px `--slate`, then `respelling · class` in mono; right-aligned scheduler state with an English sub-label.

### 12. Web / desktop

Not implemented in the prototype — see option **1c** in `Mil Palavras - Redesign.dc.html`, at 1240×800. Same content, three columns: a 196px left rail carrying all destinations grouped under the same five labels; a session-led centre column; a 268px right column with progress bars, the 7-day chart and a pull-quote. The masthead holds the brand, three live stats, and the theme switch (claro/escuro/auto) — never buried in settings. Breakpoint: the existing app already switches to `#app.web` at wide widths; keep that mechanism.

## Interactions & behaviour

### Navigation model

- `screen === null` → a *place*; the tab bar is visible. Any non-null `screen` → a *session*; the tab bar is hidden and the screen owns the viewport.
- Sessions are entered from Hoje's CTA, from Estudar, or from a "a seguir" row; they are left only by `sair`/`voltar` or by completing.
- Switching tabs stops any read-along timer, clears the open gloss, and resets the Estudar page to step 1.
- Nothing is a dead end: every session screen has an explicit exit, and the end screen offers two onward actions.

### 1. Audio first

Every card face carries a play control, and speed is inline rather than buried in settings.

- Front: a 56px `--btn` square (glyph `▶`) with `ouvir` / `listen · duarte pt-pt`, plus three 46×44 speed chips.
- Back and Escolha: a compact play button with the same glyph and label beside the speed chips.
- While playing, the button becomes `--teal` with `--paper` text and the glyph flips to `❚❚`; the label becomes `a falar… / playing · duarte pt-pt`.
- **Auto-play on reveal**: revealing a card plays it. Flashcard mode (front already shown) plays on entry and on every advance.
- Prototype timings stand in for real audio: 1 600 ms at 0,7×, 1 250 ms at 0,85×, 900 ms at 1×. In production, drive the state from real `Audio` events (`play`/`ended`) and set `playbackRate` from the chosen speed, preserving pitch.

### 2. Session length up front

`sesLen ∈ {5, 10, 20, Infinity}`, default **10**, persisted. The picker appears in the home panel and on the bucket screen (four 46px cells, minute estimates 2/5/10/all). The session queue is `pool.slice(0, min(sesLen, pool.length))`. Everything downstream reads the planned number, not the raw due count: the big numeral, `10 dos 23 por rever · cerca de 5 min`, and `start · 10 cards`. Estimate ≈ 30 s per card: `max(1, round(planned × 0.5))` minutes.

### 3. Context before translation

Each card carries a `cue` — its example sentence with the target word replaced by `____` (e.g. `O ____ para o Porto sai às nove.`). The front shows the cue; the back shows the full sentence *above* the translation. The learner meets the word in use before the English.

### 4. Progress in plain words

Coverage estimate: `cov = known ? round(78 × sqrt(known / total)) : 0`, where `known` is cards with interval ≥ 21 days. The 78 is the approximate share of ordinary text covered by the top-1000 words; the square root models the fact that early words are the frequent ones. Rendered as *"Já reconheces cerca de 45 em cada 100 palavras de uma frase comum."* / *"You already recognise about 45 of every 100 words in an ordinary sentence."* At zero: *"Ainda não há palavras ganhas — a primeira sessão muda isso."* Shown on Hoje under the bar and at the top of Memória. Against the real deck, substitute the app's own frequency data if available — an honest measured number beats the estimate.

### 5. Word families

Each card carries 3–4 companions shown on the back as chips. Authored, not generated — they are collocations and situational neighbours, not morphological derivations: *o comboio* → a estação / o bilhete / a linha / atrasado; *a casa de banho* → a toalha / o espelho / a torneira; *o autocarro* → a paragem / o passe / o motorista; *apesar de* → embora / contudo / mesmo assim. Worth extending: a family could seed a bucket in Estudar.

### 6. Night mode

Third theme, described under Design tokens. Reachable from the Eu segmented control and from the home cycle button.

### 7. Honest empty state

When nothing is due, the home panel does not show a zero and does not invent work. It shows *"Nada por rever. Está tudo em dia."* / *"Nothing is due. You are up to date."*, then when work returns — `Amanhã voltam 8 cartões.`, or `Os próximos 5 voltam dentro de 3 dias.`, or `Nada agendado nos próximos 7 dias.` — then **one** offer (*Ler um texto*), with practice available as a quiet mono link (`ou pratica · or practise anyway`). Practising when nothing is due runs Escolha over the whole deck and does not corrupt the schedule beyond normal grading.

### Grading and the forecast chart

The prototype uses a deliberately simple stand-in for the app's FSRS scheduler — **keep the real one** and read these as the shape of the UI contract:

- Again → interval 0, `lapses + 1`, and the card is **re-appended to the current queue** so it comes back in this session.
- Hard → `max(1, iv × 1.2)`; Good → `iv × 2.5` (or 4 d if new); Easy → `iv × 3.5` (or 14 d if new).
- Buttons display the resulting interval, formatted `hoje` / `N d` / `N m` (months above 30 days).
- Due = interval < 21 days; known = ≥ 21 days; trouble = `lapses ≥ 2` and not yet known.
- Session tallies (`doneToday`, `rightToday`, `againToday`) drive Memória's "hoje" row and the end screen; accuracy is `round(right / done × 100)`.

**7-day forecast** (`próximos 7 dias`): bucket every card by `round(interval)` into days 0–6; day 0 is the due count. Bars are 60% of the column width, max 44px tall, scaled to the highest bucket, minimum 2px so an empty day still reads as a day. Today's bar and numeral are `--terra`; the rest are `--rule2` with `--ink` numerals. Labels are `hoje` then real weekday abbreviations (`dom seg ter qua qui sex sáb`) offset from the current day. Grading a card Easy visibly moves it out of today's bar into a later one — the chart must recompute from card state, not from a stored snapshot.

### Language policy

**Every Portuguese string has an English equivalent visible on screen** — no hover, no tap-to-reveal. Patterns: sub-line under the PT string; inline small gloss after a row title; mono uppercase English at the opposite end of a flex row; both lines inside a note. Portuguese is European throughout (`comboio`, `autocarro`, `casa de banho`, `pequeno-almoço`, `telemóvel`; `tu` forms; `estar a` + infinitive), and the notes call out Brazilian forms explicitly rather than silently avoiding them.

## State

Prototype state, as a specification of what the screens need:

| Key | Type | Notes |
|---|---|---|
| `tab` | `hoje \| ler \| estudar \| mem \| eu` | active place |
| `screen` | `null \| rever \| escolha \| fim \| reading \| conversa \| dic` | non-null hides the tab bar |
| `mode` | `rever \| cartoes \| escolha` | `cartoes` starts with the answer shown |
| `estMode` | `null \| cartoes \| escolha` | non-null = bucket step |
| `theme` | `light \| dark \| night \| auto` | **persist** |
| `sysDark` | boolean | from `matchMedia`, live |
| `sesLen` | `5 \| 10 \| 20 \| Infinity` | **persist** |
| `perDay` | number | 2–20 step 2, **persist** |
| `speed` | `slow \| normal \| natural` | **persist** |
| `speaking` | boolean | audio playing |
| `prog` | `[{ iv, lapses }]` | per-card scheduler state, **persist** |
| `queue` / `qi` | `[cardIndex]` / number | current session |
| `shown` / `pick` | boolean / string¦null | card revealed; chosen option |
| `doneToday` / `rightToday` / `againToday` | numbers | reset daily |
| `line` / `gloss` / `playing` | number / object¦null / boolean | reading state |
| `ct` / `thread` | number / messages | conversation |
| `dicFilter` | `all \| n \| v \| o` | dictionary filter |

The existing app already persists progress in `localStorage`; extend that record with the theme, session length and speed preferences rather than introducing a second store. Everything the prototype computes — due list, known/started counts, coverage, forecast, deck states, buckets — is **derived from `prog` at render time**, never stored.

## Assets

None. No images, no icon font, no SVG illustrations — every glyph is a text character (`→ ← ▶ ❚❚ − + ✳ ✓`) and every shape is a bordered or filled rectangle. Fonts are Newsreader, Karla and IBM Plex Mono, already in the repo's `fonts/` and `fonts.css`; the prototype loads them from Google Fonts only because it runs standalone — use the local files.

## Files

In this bundle:

- `Mil Palavras - Protótipo.dc.html` — the working prototype (primary reference)
- `Mil Palavras - Redesign.dc.html` — options board + 13 static screens, incl. Escrever / Ditado / Falar and the web dashboard
- `support.js` — runtime needed by both files; not part of the design
- `source/index.html`, `source/fonts.css` — copies of the current app as read from `mikebenaron/mil-palavras@main`, for token and behaviour comparison

Open either HTML file directly in a browser. In the prototype, *Recomeçar o protótipo* under **Eu** resets all state.

## Not designed yet

Escrever, Ditado, Falar and O ou A? exist as static screens in the options board (2e, 2f, 2g) but are not interactive in the prototype — they inherit the session frame from Rever exactly. Gramática, Verbo a verbo, Conjugações and Método are unaddressed; the reference group in Estudar has room for them. The web/desktop layout exists only as option 1c.
